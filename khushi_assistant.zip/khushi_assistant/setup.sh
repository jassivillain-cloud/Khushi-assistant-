#!/bin/bash

echo "💕 Khushi Assistant Setup Script"
echo "================================="
echo ""

# Check Flutter
if ! command -v flutter &> /dev/null; then
    echo "❌ Flutter not found. Please install Flutter first."
    exit 1
fi

echo "✅ Flutter found"

# Get dependencies
echo "📦 Getting dependencies..."
flutter pub get

# Check for google-services.json
if [ ! -f "android/app/google-services.json" ]; then
    echo "⚠️  Warning: google-services.json not found!"
    echo "   Please add your Firebase config file."
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Add your API keys in lib/services/"
echo "2. Add google-services.json to android/app/"
echo "3. Run: flutter build apk"
echo ""
echo "💕 Khushi is ready to be built!"
