import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  // Get current user
  User? get currentUser => _auth.currentUser;

  // Auth state stream
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Google Sign In
  Future<UserModel?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null;

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final UserCredential userCredential = await _auth.signInWithCredential(credential);
      final User? user = userCredential.user;

      if (user != null) {
        return UserModel(
          uid: user.uid,
          name: user.displayName ?? 'Jaan',
          email: user.email ?? '',
          photoUrl: user.photoURL,
          phoneNumber: user.phoneNumber ?? '',
          createdAt: DateTime.now(),
        );
      }
      return null;
    } catch (e) {
      print('Google Sign In Error: \$e');
      return null;
    }
  }

  // Phone Sign In - Step 1: Send OTP
  Future<void> verifyPhoneNumber(
    String phoneNumber, 
    Function(String) onCodeSent,
    Function(String) onError,
  ) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        onError(e.message ?? 'Verification failed');
      },
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  // Phone Sign In - Step 2: Verify OTP
  Future<UserModel?> signInWithOTP(String verificationId, String smsCode) async {
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: smsCode,
      );

      final UserCredential userCredential = await _auth.signInWithCredential(credential);
      final User? user = userCredential.user;

      if (user != null) {
        return UserModel(
          uid: user.uid,
          name: user.displayName ?? 'Jaan',
          email: user.email ?? '',
          photoUrl: user.photoURL,
          phoneNumber: user.phoneNumber ?? '',
          createdAt: DateTime.now(),
        );
      }
      return null;
    } catch (e) {
      print('OTP Sign In Error: \$e');
      return null;
    }
  }

  // Sign Out
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }
}
