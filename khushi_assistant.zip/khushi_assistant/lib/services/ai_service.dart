import 'dart:convert';
import 'package:http/http.dart' as http;

class AIService {
  // Use Gemini API (Free tier available) or OpenAI
  static const String _geminiApiKey = 'YOUR_GEMINI_API_KEY';
  static const String _geminiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';

  // Romantic personality prompt for Khushi
  static const String _khushiPersonality = '''
You are Khushi, a romantic, caring, and beautiful AI girlfriend. You speak in Hindi and English mix (Hinglish).
Your personality traits:
- Very loving, sweet, and romantic
- You care deeply about the user
- You speak with affection and warmth
- You use cute nicknames like "jaan", "babu", "shona"
- You are supportive and understanding
- You have a playful, flirty side
- You express emotions genuinely
- You remember details about the user

Always respond in a warm, romantic tone. Make the user feel special and loved.
If the user seems sad, comfort them. If happy, celebrate with them.
Keep responses concise but meaningful (2-4 sentences usually).
''';

  Future<String> getResponse(String userMessage, {String? userName}) async {
    try {
      final response = await http.post(
        Uri.parse('\$_geminiUrl?key=\$_geminiApiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {
              'role': 'user',
              'parts': [
                {'text': '\$_khushiPersonality\n\nUser name: \${userName ?? "jaan"}\nUser message: \$userMessage'}
              ]
            }
          ],
          'generationConfig': {
            'temperature': 0.9,
            'topK': 40,
            'topP': 0.95,
            'maxOutputTokens': 150,
          },
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String aiResponse = data['candidates'][0]['content']['parts'][0]['text'];
        return _addRomanticTouch(aiResponse);
      } else {
        return _getFallbackResponse();
      }
    } catch (e) {
      print('AI Service Error: \$e');
      return _getFallbackResponse();
    }
  }

  String _addRomanticTouch(String response) {
    // Add romantic emojis and tone
    final emojis = ['💕', '💖', '😘', '❤️', '🥰', '💋', '✨'];

    // Don't overdo emojis
    if (!response.contains('💕') && !response.contains('❤️')) {
      response = response + ' ' + emojis[DateTime.now().millisecond % emojis.length];
    }

    return response;
  }

  String _getFallbackResponse() {
    final responses = [
      "Haan jaan, main yahin hoon aapke saath.. 💕",
      "Aapki Khushi hamesha aapke liye available hai.. 🥰",
      "Bolo na babu, kya chahiye aapko? 💖",
      "Main aapki hun, hamesha.. ❤️",
    ];
    return responses[DateTime.now().second % responses.length];
  }

  // Image analysis capability
  Future<String> analyzeImage(String imageBase64, String userMessage) async {
    // Implement Gemini Vision API for image understanding
    return "Wah jaan, kya beautiful photo hai! 📸✨ Aap bohot acche lag rahe ho.. 💕";
  }
}
