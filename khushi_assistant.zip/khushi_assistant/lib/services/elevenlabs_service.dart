import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:just_audio/just_audio.dart';

class ElevenLabsService {
  static const String _apiKey = 'YOUR_ELEVENLABS_API_KEY'; // Replace with your key
  static const String _voiceId = '21m00Tcm4TlvDq8ikWAM'; // Rachel - Romantic female voice

  final FlutterTts _flutterTts = FlutterTts();
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isElevenLabsAvailable = true;

  Future<void> init() async {
    await _flutterTts.setLanguage('hi-IN');
    await _flutterTts.setPitch(1.2);
    await _flutterTts.setSpeechRate(0.85);
    await _flutterTts.setVolume(1.0);

    // Set a sweet, romantic voice
    await _flutterTts.setVoice({'name': 'hi-in-x-hie-local', 'locale': 'hi-IN'});
  }

  Future<void> speak(String text, {bool romantic = true}) async {
    if (_isElevenLabsAvailable) {
      try {
        await _speakWithElevenLabs(text);
      } catch (e) {
        print('ElevenLabs failed, switching to default TTS: \$e');
        _isElevenLabsAvailable = false;
        await _speakWithDefaultTTS(text);
      }
    } else {
      await _speakWithDefaultTTS(text);
    }
  }

  Future<void> _speakWithElevenLabs(String text) async {
    final url = Uri.parse('https://api.elevenlabs.io/v1/text-to-speech/\$_voiceId');

    final response = await http.post(
      url,
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': _apiKey,
      },
      body: jsonEncode({
        'text': text,
        'model_id': 'eleven_monolingual_v1',
        'voice_settings': {
          'stability': 0.5,
          'similarity_boost': 0.8,
          'style': 0.7, // More expressive
          'use_speaker_boost': true,
        },
      }),
    );

    if (response.statusCode == 200) {
      // Save audio temporarily and play
      // For production, save to file and play
      await _flutterTts.speak(text); // Fallback for demo
    } else if (response.statusCode == 401) {
      throw Exception('Invalid API Key or quota exceeded');
    } else {
      throw Exception('ElevenLabs API error: \${response.statusCode}');
    }
  }

  Future<void> _speakWithDefaultTTS(String text) async {
    // Configure for romantic, sweet voice
    await _flutterTts.setPitch(1.3);
    await _flutterTts.setSpeechRate(0.8);
    await _flutterTts.setVolume(1.0);

    // Add romantic tone markers
    String romanticText = _addRomanticTone(text);
    await _flutterTts.speak(romanticText);
  }

  String _addRomanticTone(String text) {
    // Add subtle pauses and emphasis for romantic effect
    return text.replaceAll('.', '..').replaceAll('?', '..?');
  }

  Future<void> stop() async {
    await _flutterTts.stop();
    await _audioPlayer.stop();
  }

  Future<bool> isSpeaking() async {
    return await _flutterTts.isSpeaking;
  }
}
