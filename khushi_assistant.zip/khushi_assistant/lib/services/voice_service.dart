import 'package:speech_to_text/speech_to_text.dart';
import 'package:permission_handler/permission_handler.dart';

class VoiceService {
  final SpeechToText _speechToText = SpeechToText();
  bool _isListening = false;
  bool _isInitialized = false;

  // Wake word detection
  static const String WAKE_WORD = 'hello khushi';
  static const String WAKE_WORD_HINDI = 'hello khushi';

  Future<bool> init() async {
    // Request microphone permission
    var status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      return false;
    }

    _isInitialized = await _speechToText.initialize(
      onError: (error) => print('Speech Error: \$error'),
      onStatus: (status) => print('Speech Status: \$status'),
    );

    return _isInitialized;
  }

  Future<bool> startListening(Function(String) onResult) async {
    if (!_isInitialized) {
      bool initialized = await init();
      if (!initialized) return false;
    }

    if (_isListening) return false;

    _isListening = true;

    await _speechToText.listen(
      onResult: (result) {
        if (result.finalResult) {
          onResult(result.recognizedWords);
          _isListening = false;
        }
      },
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
      localeId: 'en_IN', // Indian English + Hindi support
    );

    return true;
  }

  Future<void> stopListening() async {
    _isListening = false;
    await _speechToText.stop();
  }

  bool get isListening => _isListening;

  // Check if wake word detected
  bool checkWakeWord(String text) {
    String lowerText = text.toLowerCase();
    return lowerText.contains(WAKE_WORD) || 
           lowerText.contains('hey khushi') ||
           lowerText.contains('khushi') && lowerText.contains('hello');
  }

  // Background wake word detection (simplified)
  // For production, use native background services
  Future<void> startBackgroundListening(Function(String) onWakeWord) async {
    // This requires platform-specific implementation
    // For Android: Use foreground service with microphone access
    print('Background listening started...');
  }
}
