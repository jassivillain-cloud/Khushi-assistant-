import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:math' as math;
import '../providers/chat_provider.dart';
import '../providers/auth_provider.dart';
import '../providers/voice_provider.dart';
import '../widgets/chat_bubble.dart';
import '../widgets/typing_indicator.dart';
import '../widgets/voice_button.dart';
import 'profile_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen>
    with TickerProviderStateMixin {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  late AnimationController _earthController;

  @override
  void initState() {
    super.initState();
    _earthController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    )..repeat();

    // Initialize voice
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<VoiceProvider>(context, listen: false).init();
    });
  }

  @override
  void dispose() {
    _earthController.dispose();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final chatProvider = Provider.of<ChatProvider>(context);
    final authProvider = Provider.of<AuthProvider>(context);
    final voiceProvider = Provider.of<VoiceProvider>(context);

    // Auto scroll when new messages
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

    return Scaffold(
      backgroundColor: const Color(0xFF1A0A2E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2D1B4E).withOpacity(0.95),
        elevation: 0,
        leadingWidth: 80,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: _buildEarthLogo(),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text(
                  'Khushi',
                  style: TextStyle(
                    color: Color(0xFFF8E1F4),
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                  ),
                ),
              ],
            ),
            Text(
              voiceProvider.isListening 
                ? 'Listening... 🎤' 
                : chatProvider.isTyping 
                  ? 'Typing...' 
                  : 'Online 💕',
              style: const TextStyle(
                color: Color(0xFFB39DDB),
                fontSize: 12,
              ),
            ),
          ],
        ),
        actions: [
          // Voice Mode Toggle
          IconButton(
            icon: Icon(
              chatProvider.isVoiceMode ? Icons.volume_up : Icons.volume_off,
              color: chatProvider.isVoiceMode 
                ? const Color(0xFFE91E63) 
                : const Color(0xFFB39DDB),
            ),
            onPressed: () => chatProvider.toggleVoiceMode(),
          ),
          // Profile
          IconButton(
            icon: const Icon(Icons.person_outline, color: Color(0xFFF8E1F4)),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ProfileScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Chat Messages
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF1A0A2E),
                    const Color(0xFF2D1B4E).withOpacity(0.3),
                  ],
                ),
              ),
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.all(16),
                itemCount: chatProvider.messages.length + (chatProvider.isTyping ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index == chatProvider.messages.length) {
                    return const TypingIndicator();
                  }
                  final message = chatProvider.messages[index];
                  return ChatBubble(
                    message: message,
                    isFirst: index == 0 || 
                      chatProvider.messages[index - 1].isUser != message.isUser,
                  );
                },
              ),
            ),
          ),
          // Input Area
          _buildInputArea(chatProvider, voiceProvider),
        ],
      ),
    );
  }

  Widget _buildEarthLogo() {
    return AnimatedBuilder(
      animation: _earthController,
      builder: (context, child) {
        return Transform.rotate(
          angle: _earthController.value * 2 * math.pi,
          child: Container(
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const RadialGradient(
                colors: [
                  Color(0xFF6B2D5C),
                  Color(0xFF2D1B4E),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFE91E63).withOpacity(0.3),
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: const Icon(
              Icons.public,
              color: Color(0xFFFF4081),
              size: 24,
            ),
          ),
        );
      },
    );
  }

  Widget _buildInputArea(ChatProvider chatProvider, VoiceProvider voiceProvider) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF2D1B4E).withOpacity(0.95),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 20,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            // Image picker
            IconButton(
              icon: const Icon(Icons.image, color: Color(0xFFFF4081)),
              onPressed: () => _showImagePicker(chatProvider),
            ),
            // Text Input
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF3D2B5E),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: TextField(
                  controller: _messageController,
                  style: const TextStyle(color: Color(0xFFF8E1F4)),
                  decoration: const InputDecoration(
                    hintText: 'Message Khushi... 💕',
                    hintStyle: TextStyle(color: Color(0xFFB39DDB)),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 20, 
                      vertical: 14,
                    ),
                  ),
                  onSubmitted: (text) => _sendMessage(chatProvider),
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Voice Button
            VoiceButton(
              isListening: voiceProvider.isListening,
              onTap: () => _handleVoice(voiceProvider, chatProvider),
            ),
            const SizedBox(width: 8),
            // Send Button
            GestureDetector(
              onTap: () => _sendMessage(chatProvider),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFFE91E63), Color(0xFFFF4081)],
                  ),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.send,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _sendMessage(ChatProvider chatProvider) async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    _messageController.clear();
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    await chatProvider.sendMessage(
      text, 
      userName: authProvider.user?.name,
    );
  }

  Future<void> _handleVoice(VoiceProvider voiceProvider, ChatProvider chatProvider) async {
    if (voiceProvider.isListening) {
      await voiceProvider.stopListening();
    } else {
      await voiceProvider.startListening((text) async {
        if (text.isNotEmpty) {
          final authProvider = Provider.of<AuthProvider>(context, listen: false);
          await chatProvider.sendMessage(
            text,
            userName: authProvider.user?.name,
          );
        }
      });
    }
  }

  void _showImagePicker(ChatProvider chatProvider) {
    // Implement image picker
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF2D1B4E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Send Image to Khushi',
              style: TextStyle(
                color: Color(0xFFF8E1F4),
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFFE91E63)),
              title: const Text('Camera', style: TextStyle(color: Color(0xFFF8E1F4))),
              onTap: () {
                Navigator.pop(context);
                // Implement camera
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFFE91E63)),
              title: const Text('Gallery', style: TextStyle(color: Color(0xFFF8E1F4))),
              onTap: () {
                Navigator.pop(context);
                // Implement gallery
              },
            ),
          ],
        ),
      ),
    );
  }
}
