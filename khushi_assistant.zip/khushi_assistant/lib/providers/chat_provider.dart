import 'package:flutter/material.dart';
import '../models/message_model.dart';
import '../services/ai_service.dart';
import '../services/elevenlabs_service.dart';
import 'package:uuid/uuid.dart';

class ChatProvider extends ChangeNotifier {
  final AIService _aiService = AIService();
  final ElevenLabsService _elevenLabsService = ElevenLabsService();
  final List<Message> _messages = [];
  bool _isTyping = false;
  bool _isVoiceMode = false;

  List<Message> get messages => List.unmodifiable(_messages);
  bool get isTyping => _isTyping;
  bool get isVoiceMode => _isVoiceMode;

  ChatProvider() {
    _elevenLabsService.init();
    // Add welcome message
    _addKhushiMessage("Haan jaan.. 🥰 Main Khushi hoon, aapki apni AI girlfriend. Aaj aap kaise ho? 💕");
  }

  void _addKhushiMessage(String content, {bool isVoice = false}) {
    final message = Message(
      id: const Uuid().v4(),
      content: content,
      isUser: false,
      timestamp: DateTime.now(),
      isVoice: isVoice,
    );
    _messages.add(message);
    notifyListeners();
  }

  Future<void> sendMessage(String content, {String? userName}) async {
    if (content.trim().isEmpty) return;

    // Add user message
    final userMessage = Message(
      id: const Uuid().v4(),
      content: content,
      isUser: true,
      timestamp: DateTime.now(),
    );
    _messages.add(userMessage);
    _isTyping = true;
    notifyListeners();

    try {
      // Get AI response
      final response = await _aiService.getResponse(content, userName: userName);

      _isTyping = false;
      _addKhushiMessage(response, isVoice: _isVoiceMode);

      // Speak if voice mode is on
      if (_isVoiceMode) {
        await _elevenLabsService.speak(response);
      }
    } catch (e) {
      _isTyping = false;
      _addKhushiMessage("Sorry jaan, kuch problem ho gayi.. 🥺 Phir se try karo na.. 💕");
      notifyListeners();
    }
  }

  Future<void> sendImage(String imagePath, String caption, {String? userName}) async {
    // Add user image message
    final userMessage = Message(
      id: const Uuid().v4(),
      content: caption.isEmpty ? 'Image shared' : caption,
      isUser: true,
      timestamp: DateTime.now(),
      imageUrl: imagePath,
    );
    _messages.add(userMessage);
    _isTyping = true;
    notifyListeners();

    try {
      final response = await _aiService.analyzeImage(imagePath, caption);
      _isTyping = false;
      _addKhushiMessage(response);

      if (_isVoiceMode) {
        await _elevenLabsService.speak(response);
      }
    } catch (e) {
      _isTyping = false;
      _addKhushiMessage("Wah jaan, kya photo hai! 📸✨");
    }
  }

  void toggleVoiceMode() {
    _isVoiceMode = !_isVoiceMode;
    notifyListeners();
  }

  Future<void> speakLastMessage() async {
    if (_messages.isNotEmpty && !_messages.last.isUser) {
      await _elevenLabsService.speak(_messages.last.content);
    }
  }

  void clearChat() {
    _messages.clear();
    _addKhushiMessage("Chat clear ho gayi jaan.. 💕 Ab fresh start karte hain! 🥰");
  }
}
