import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  UserModel? _user;
  bool _isLoading = false;
  String? _error;

  UserModel? get user => _user;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _user != null;

  AuthProvider() {
    _checkCurrentUser();
  }

  void _checkCurrentUser() {
    final currentUser = _authService.currentUser;
    if (currentUser != null) {
      _user = UserModel(
        uid: currentUser.uid,
        name: currentUser.displayName ?? 'Jaan',
        email: currentUser.email ?? '',
        photoUrl: currentUser.photoURL,
        phoneNumber: currentUser.phoneNumber ?? '',
        createdAt: DateTime.now(),
      );
      notifyListeners();
    }
  }

  Future<bool> signInWithGoogle() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _user = await _authService.signInWithGoogle();
      _isLoading = false;
      notifyListeners();
      return _user != null;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> verifyPhone(String phoneNumber, Function(String) onCodeSent) async {
    _isLoading = true;
    notifyListeners();

    await _authService.verifyPhoneNumber(
      phoneNumber,
      (verificationId) {
        _isLoading = false;
        notifyListeners();
        onCodeSent(verificationId);
      },
      (error) {
        _error = error;
        _isLoading = false;
        notifyListeners();
      },
    );
  }

  Future<bool> verifyOTP(String verificationId, String otp) async {
    _isLoading = true;
    notifyListeners();

    _user = await _authService.signInWithOTP(verificationId, otp);
    _isLoading = false;
    notifyListeners();
    return _user != null;
  }

  Future<void> signOut() async {
    await _authService.signOut();
    _user = null;
    notifyListeners();
  }
}
