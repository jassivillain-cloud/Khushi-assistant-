import 'package:flutter/material.dart';
import '../services/voice_service.dart';
import '../services/elevenlabs_service.dart';

class VoiceProvider extends ChangeNotifier {
  final VoiceService _voiceService = VoiceService();
  final ElevenLabsService _elevenLabsService = ElevenLabsService();

  bool _isListening = false;
  bool _isSpeaking = false;
  String _lastRecognizedText = '';

  bool get isListening => _isListening;
  bool get isSpeaking => _isSpeaking;
  String get lastRecognizedText => _lastRecognizedText;

  Future<bool> init() async {
    await _elevenLabsService.init();
    return await _voiceService.init();
  }

  Future<void> startListening(Function(String) onResult) async {
    _isListening = true;
    notifyListeners();

    bool started = await _voiceService.startListening((text) {
      _lastRecognizedText = text;
      _isListening = false;
      notifyListeners();
      onResult(text);
    });

    if (!started) {
      _isListening = false;
      notifyListeners();
    }
  }

  Future<void> stopListening() async {
    await _voiceService.stopListening();
    _isListening = false;
    notifyListeners();
  }

  Future<void> speak(String text) async {
    _isSpeaking = true;
    notifyListeners();

    await _elevenLabsService.speak(text);

    _isSpeaking = false;
    notifyListeners();
  }

  Future<void> stopSpeaking() async {
    await _elevenLabsService.stop();
    _isSpeaking = false;
    notifyListeners();
  }

  // Check wake word
  bool checkWakeWord(String text) {
    return _voiceService.checkWakeWord(text);
  }
}
