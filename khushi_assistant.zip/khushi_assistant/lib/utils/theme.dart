import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class KhushiTheme {
  // Romantic Deep Colors
  static const Color primaryColor = Color(0xFF6B2D5C);
  static const Color secondaryColor = Color(0xFFE91E63);
  static const Color accentColor = Color(0xFFFF4081);
  static const Color backgroundColor = Color(0xFF1A0A2E);
  static const Color surfaceColor = Color(0xFF2D1B4E);
  static const Color cardColor = Color(0xFF3D2B5E);
  static const Color textColor = Color(0xFFF8E1F4);
  static const Color mutedTextColor = Color(0xFFB39DDB);
  static const Color userBubbleColor = Color(0xFF6B2D5C);
  static const Color khushiBubbleColor = Color(0xFF4A148C);

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: backgroundColor,
      primaryColor: primaryColor,
      colorScheme: const ColorScheme.dark(
        primary: primaryColor,
        secondary: secondaryColor,
        surface: surfaceColor,
        background: backgroundColor,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: textColor,
        onBackground: textColor,
      ),
      textTheme: TextTheme(
        displayLarge: GoogleFonts.poppins(
          fontSize: 32, fontWeight: FontWeight.bold, color: textColor,
        ),
        displayMedium: GoogleFonts.poppins(
          fontSize: 24, fontWeight: FontWeight.w600, color: textColor,
        ),
        bodyLarge: GoogleFonts.poppins(
          fontSize: 16, color: textColor,
        ),
        bodyMedium: GoogleFonts.poppins(
          fontSize: 14, color: mutedTextColor,
        ),
      ),
      cardTheme: CardTheme(
        color: cardColor,
        elevation: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: secondaryColor,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          elevation: 8,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceColor,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(25),
          borderSide: BorderSide.none,
        ),
        hintStyle: GoogleFonts.poppins(color: mutedTextColor),
      ),
    );
  }
}
