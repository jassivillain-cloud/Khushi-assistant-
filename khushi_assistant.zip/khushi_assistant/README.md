# 💕 Khushi - Your Romantic AI Companion

A beautiful Flutter app featuring Khushi, your romantic AI girlfriend with voice chat, image sharing, and wake word detection.

## ✨ Features

- 🔐 **Login System**: Google Sign-In & Phone OTP
- 💬 **Romantic Chat**: AI-powered romantic conversations
- 🎙️ **Voice Chat**: Speak with Khushi using ElevenLabs voice
- 🖼️ **Image Sharing**: Send images to Khushi
- 🌍 **Animated Earth Logo**: Beautiful rotating globe in app bar
- 🎵 **Voice Fallback**: Auto-switches to default TTS if ElevenLabs quota exceeds
- 📱 **Background Listening**: Say "Hello Khushi" even when screen is off
- 💖 **Beautiful UI**: Romantic dark theme with pink accents

## 🚀 Setup Instructions

### Prerequisites
- Flutter SDK (>=3.0.0)
- Android Studio / VS Code
- Firebase Account
- ElevenLabs API Key (optional, has fallback)
- Gemini API Key (for AI responses)

### Step 1: Clone & Setup
```bash
cd khushi_assistant
flutter pub get
```

### Step 2: Firebase Setup
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create new project named "Khushi Assistant"
3. Add Android app with package name: `com.khushi.assistant`
4. Download `google-services.json` and place in `android/app/`
5. Enable Authentication: Google Sign-In & Phone

### Step 3: API Keys Setup

#### ElevenLabs (Voice - Optional)
1. Go to [ElevenLabs](https://elevenlabs.io)
2. Get API Key from dashboard
3. Open `lib/services/elevenlabs_service.dart`
4. Replace `YOUR_ELEVENLABS_API_KEY` with your key

#### Gemini AI (Required)
1. Go to [Google AI Studio](https://makersuite.google.com)
2. Get API Key
3. Open `lib/services/ai_service.dart`
4. Replace `YOUR_GEMINI_API_KEY` with your key

### Step 4: Build APK
```bash
# Development APK
flutter build apk

# Release APK
flutter build apk --release

# App Bundle (for Play Store)
flutter build appbundle
```

APK will be at: `build/app/outputs/flutter-apk/app-release.apk`

## 🎨 Customization

### Change Voice
Edit `lib/services/elevenlabs_service.dart`:
```dart
static const String _voiceId = 'YOUR_VOICE_ID';
```

### Change Theme Colors
Edit `lib/utils/theme.dart`:
- `primaryColor`: Main purple
- `secondaryColor`: Pink accent
- `backgroundColor`: Dark background

### Change AI Personality
Edit `lib/services/ai_service.dart`:
Modify `_khushiPersonality` string to change how Khushi behaves.

## 📱 Permissions Required

- Microphone (Voice chat)
- Camera (Image sharing)
- Storage (Save images)
- Phone (Auto-call feature)
- Contacts (Auto-message feature)
- Ignore Battery Optimization (Background listening)

## 🔧 Troubleshooting

### Build Errors
```bash
flutter clean
flutter pub get
cd android && ./gradlew clean && cd ..
flutter build apk
```

### Voice Not Working
- Check microphone permission in app settings
- Ensure ElevenLabs API key is valid or fallback will work

### Background Listening Not Working
- Disable battery optimization for the app
- Grant all permissions
- Some devices need special settings (Xiaomi, Oppo, etc.)

## 📄 License

This project is for personal use. Do not distribute without permission.

---

Made with 💕 for your happiness
